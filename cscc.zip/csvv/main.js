const csv = require('csv-parser')
const fs = require('fs');

 let rsStream = fs.createReadStream("sample.csv");
 let wsStream = fs.createWriteStream('dummy.txt', { flags : 'w' });

    rsStream.on("data" , (data) => {
        wsStream.write((data), (err)=>{
            if(err){
                console.log(err.message);
            }
        })
    })





    
//     writeStream = fs.createWriteStream('dummy.txt' + process.pid, {flags: 'w', encoding: 'utf-8' }),
//     stream = require('stream'),
//     stringifier = new stream.Transform();
// stringifier._writableState.objectMode = true;
// stringifier._transform = function (data, encoding, done) {
//     this.push(JSON.stringify(data));
//     this.push('\n');
//     done();
// }
// rowFeedDao.getRowFeedsStream(merchantId, jobId)
// .pipe(stringifier)
// .pipe(writeStream).on('error', function (err) {
//    // handle error condition
// }

    // rsStream.pipe(wsStream);

// const results = [];

// fs.createReadStream('sample.csv')
//   .pipe(csv())
//   .on('data', (row) => {
//     console.log(row);
//     fs.writeFileSync('./dummy.txt', JSON.stringify(row) , 'utf-8');
//     //fs.writeFile('dummy.txt',JSON.stringify(row));
//     fs.writeFileSync('./data.json', JSON.stringify(row, null, 2) , 'utf-8');
//   })
//   .on('end', () => {
//     writeStream.write(results,(err) => {
//         if(err){
//             console.log(err.message);
//         }
//     })
//   });




// // fs.createReadStream('sample.csv')
// //   .pipe(csv({}))
// //   .on('data', (data) => results.push(data))
// //   .on('end', () => {
// //     console.log(results);
// //   });


// // fs.createReadStream('sample.csv')
// //   .pipe(csv({}))
// //   .on('data', (data) => results.push(data))
// //   .on('end', () => {
// //     results.map(function(element){
// //         fs.writeFileSync('dummy.txt',String(element));
// //     })
// //   });


// // var parse = require('csv-parse');
// // var parser = parse({columns: true}, function (err, records) {
// // 	console.log(records);
// // });

// // fs.createReadStream(__dirname+'/sample.csv').pipe(parser);

// //   fs.createReadStream('sample.csv')
// //   .pipe(csv())
// //   .on('data', (data) => {
// //     fs.writeFileSync('dummy.txt',String(data));
// //   })
// //   .on('end', () => {
// //     console.log('CSV file successfully processed');
// //   });

// var writeStream = fs.createWriteStream('someFile.txt', { flags : 'w' });
// var readStream = new MyReadStream();

// readStream.pipe(writeStream);
// writeStream.on('close', function () {
//     console.log('All done!');
// });
